#!/bin/bash
export PORT=8080
export HOSTNAME=0.0.0.0
node server.js
