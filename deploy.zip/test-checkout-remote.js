const jwt = 'header.' + btoa(JSON.stringify({ staff_id: 'any' })) + '.sig';
fetch('https://gqtmbjazzlosatgmcfxh.supabase.co/functions/v1/clock-action', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${jwt}` },
  body: JSON.stringify({ action: 'check_out', gps_lat: 0, gps_lng: 0 })
}).then(async res => {
  console.log(res.status, await res.text());
});
