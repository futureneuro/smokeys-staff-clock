module.exports=[20710,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_dashboard_page_actions_b058c280.js.map