module.exports=[24361,(a,b,c)=>{b.exports=a.x("util",()=>require("util"))}];

//# sourceMappingURL=%5Bexternals%5D_util_be9989c7._.js.map