module.exports=[28568,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_page_actions_c7bd1b4f.js.map