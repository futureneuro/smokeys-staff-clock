var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/resolve-maps-url/route.js")
R.c("server/chunks/[root-of-the-server]__c3aa2a84._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_resolve-maps-url_route_actions_bbdcd929.js")
R.m(69284)
module.exports=R.m(69284).exports
